import sys

print('Arguments:', len(sys.argv))
print('List:', str(sys.argv))